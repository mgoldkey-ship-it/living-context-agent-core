# Living-Context Agent Core
